from dataclasses import dataclass


@dataclass
class Farmaco:
    nombre: str
    precio: str
    registro_sanitario: str
    principio_activo: str
    laboratorio: str
    via_administracion: str
    formato: str
    unidad_medidad: str
    dosis: str
    # valor_unidad: str
    sku: str

    def normalizacion_principio_activo(self):
        p = self.principio_activo
        p = p.replace("|", "-")
        p = p.replace("á", "a")
        p = p.replace("é", "e")
        p = p.replace("í", "i")
        p = p.replace("ó", "o")
        p = p.replace("ú", "u")
        self.principio_activo = p

    def normalizacion_dosis(self):
        d = self.dosis
        d = d.replace("|", "-")
        d = d.replace(",", ".")
        self.dosis = d

    def normalizacion_formato(self):
        f = self.formato
        f = f.replace("UNGÜENTO", "UNGUENTO")
        f = f.replace("SOLUCION ORAL", "SOLUCION")
        f = f.replace("COMPRIMIDO RECUBIERTO", "COMPRIMIDO")
        f = f.replace("COMPRIMIDO CON RECUBRIMIENTO ENTERICO", "COMPRIMIDO")
        f = f.replace("POLVO GRANULADO PARA SOLUCION ORAL", "POLVO")
        f = f.replace("SOLUCION PARA INHALACION", "SOLUCION")
        f = f.replace("AEROSOL PARA INHALACION", "AEROSOL")
        f = f.replace("COMPRIMIDO MASTICABLE", "COMPRIMIDO")
        f = f.replace("TABLETA EFERVESCENTE", "TABLETA")
        f = f.replace("SOLUCION OFTALMICA", "SOLUCION")
        f = f.replace("SUSPENSION ORAL", "SUSPENSION")
        f = f.replace("CAPSULA CON GRANULOS CON RECUBRIMIENTO ENTERICO", "CAPSULA")
        f = f.replace("OVULOS", "OVULO")
        f = f.replace("CAPSULA BLANDA", "CAPSULA")
        f = f.replace("COMPRIMIDO LIBERACION PROLONGADA", "COMPRIMIDO")
        f = f.replace("COMPRIMIDO RECUBIERTO LIBERACION PROLONGADA", "COMPRIMIDO")
        f = f.replace("CAPSULA CON MICROGRANULOS CON RECUBRIMIENTO ENTERI", "CAPSULA")
        f = f.replace("COMPRIMIDO DISPERSABLE", "COMPRIMIDO")
        f = f.replace("COMPRIMIDO BUCODISPERSABLE", "COMPRIMIDO")
        f = f.replace("COMPRIMIDO EFERVESCENTE", "COMPRIMIDO")
        f = f.replace("COMPRIMIDO SUBLINGUAL", "COMPRIMIDO")
        f = f.replace("POLVO PARA SOLUCION ORAL", "POLVO")
        f = f.replace("SOLUCION NASAL", "SOLUCION")
        f = f.replace("SOLUCION NEBULIZACION", "SOLUCION")
        f = f.replace("SOLUCION PARA ENEMA", "SOLUCION")
        f = f.replace("SOLUCION PARA ENEMA", "SOLUCION")
        self.formato = f

    def normalizacion_via_administracion(self):
        v = self.via_administracion
        v = v.replace("Á", "A")
        v = v.replace("É", "E")
        v = v.replace("Í", "I")
        v = v.replace("Ó", "O")
        v = v.replace("Ú", "U")
        v = v.replace("Ü", "U")
        v = v.replace("TOPICA", "TOPICO")
        v = v.replace(",", ".")
        self.via_administracion = v

    def normalizacion_nombre(self):
        n = self.nombre
        n = n.replace("Á", "A")
        n = n.replace("É", "E")
        n = n.replace("Í", "I")
        n = n.replace("Ó", "O")
        n = n.replace("Ú", "U")
        n = n.replace("Ü", "U")
        n = n.replace("TOPICA", "TOPICO")
        n = n.replace(",", ".")
        self.nombre = n

    def normalizacion_laboratorio(self):
        pass

    def normalizacion_precio(self):
        p = self.precio
        temp_str = ""
        for x in p:
            if x.isnumeric():
                temp_str += x
        self.precio = temp_str
        p = self.precio
        

    def normalizar(self):
        self.normalizacion_nombre()
        self.normalizacion_precio
        self.normalizacion_dosis()
        self.normalizacion_principio_activo()
        self.normalizacion_formato()
        self.normalizacion_precio()
