from typing import List
from pandas.core.frame import DataFrame
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import StaleElementReferenceException
from selenium.webdriver.support.select import Select
from selenium.webdriver.firefox.options import Options
import time
from farmaco import Farmaco
import pandas as pd
import os
from pathlib import Path


class FFraccion:
    def __init__(self):
        options = Options()
        options.headless = True
        self.driver = webdriver.Remote(
            command_executor="http://192.168.100.10:4444",
            desired_capabilities={"browserName": "firefox", "javascriptEnabled": True},
            options=options,
        )
        self.driver.set_script_timeout(10)
        self.urls_medicamentos = []
        self.data_medicamentos = []

    def shutdown(self):
        self.driver.quit()

    def create_folders(self):
        current_dir = os.path.dirname(os.path.abspath(__file__))
        Path(os.path.join(current_dir + "/data")).mkdir(parents=True, exist_ok=True)
        self.farmaco_dir = Path(os.path.join(current_dir + "/data/farmacos"))
        self.farmaco_dir.mkdir(parents=True, exist_ok=True)
        self.precios_dir = Path(os.path.join(current_dir + "/data/precios"))
        self.precios_dir.mkdir(parents=True, exist_ok=True)

    def get_categorias(self):
        driver = self.driver
        driver.get("https://www.fraccion.cl/medicamentos")
        data = driver.find_elements_by_xpath(
            "//div[@class='sub-category-item']/div[@class='picture']/a[@href]"
        )
        self.urls_categorias = [x.get_attribute("href") for x in data]

    def browse_categorias(self):
        driver = self.driver
        urls_categorias = self.urls_categorias#[:2]
        for x in urls_categorias:
            self.get_urls()
            driver.get(x)

    def get_urls(self):
        driver = self.driver
        time.sleep(2)
        urls_medicamentos = driver.find_elements_by_xpath(
            "//div[@class='ribbon-wrapper']//div[@class='picture']/a"
        )
        for x in urls_medicamentos:#[:5]
            self.urls_medicamentos.append(x.get_attribute("href"))
        self.get_next_page()

    def get_next_page(self):
        driver = self.driver
        try:
            next_button = driver.find_element_by_xpath("//li[@class='next-page']")
            if next_button:
                next_button.click()
                self.get_urls()
        except NoSuchElementException as e:
            print(e)

    def get_med_data(self):
        driver = self.driver
        urls = set(self.urls_medicamentos)#[:5]
        for x in urls:
            try:
                driver.get(x)
                print(
                    f" Cantidad de Datos de medicamentos agregados {len(self.data_medicamentos)}"
                )
                nombre = driver.find_element_by_xpath(
                    '//*[@id="product-details-form"]/div/div[1]/div[1]/h1'
                ).text.upper()
                precio = driver.find_element_by_class_name(
                    "product-price"
                ).text
                principio_activo = driver.find_element_by_xpath(
                    '//*[@id="product-details-form"]/div/div[2]/div[1]/div[2]/table/tbody/tr[5]/td[2]'
                ).text.upper()
                dosis = driver.find_element_by_xpath(
                    '//*[@id="product-details-form"]/div/div[2]/div[1]/div[2]/table/tbody/tr[6]/td[2]'
                ).text.upper()
                unidad_medidad = driver.find_element_by_xpath(
                    '//*[@id="product-details-form"]/div/div[2]/div[1]/div[2]/table/tbody/tr[7]/td[2]'
                ).text.upper()
                formato = driver.find_element_by_xpath(
                    '//*[@id="product-details-form"]/div/div[2]/div[1]/div[2]/table/tbody/tr[8]/td[2]'
                ).text.upper()
                via_administracion = driver.find_element_by_xpath(
                    '//*[@id="product-details-form"]/div/div[2]/div[1]/div[2]/table/tbody/tr[9]/td[2]'
                ).text.upper()
                registro_sanitario = driver.find_element_by_xpath(
                    '//*[@id="product-details-form"]/div/div[2]/div[1]/div[2]/table/tbody/tr[10]/td[2]'
                ).text.upper()
                laboratorio = driver.find_element_by_xpath(
                    '//*[@id="product-details-form"]/div/div[2]/div[1]/div[2]/table/tbody/tr[14]/td[2]'
                ).text.upper()
                dosis_final = f"{dosis} {unidad_medidad}"
                sku = driver.find_element_by_xpath(
                    '//div[@class="sku"]/span[@class="value"]'
                ).text
                f = Farmaco(
                    nombre=nombre,
                    precio=precio,
                    principio_activo=principio_activo,
                    dosis=dosis,
                    unidad_medidad=unidad_medidad,
                    formato=formato,
                    via_administracion=via_administracion,
                    registro_sanitario=registro_sanitario,
                    laboratorio=laboratorio,
                    sku=sku,
                )
                f.normalizar()
                self.data_medicamentos.append(f)
            except NoSuchElementException as e:
                print(e)

    def save_data(self):
        d = pd.DataFrame(self.data_medicamentos)
        dir = self.farmaco_dir 
        d.to_csv(
            os.path.join(dir, "test_csv.csv"),
            index=False,
            sep="___",
            encoding="utf-8-sig",
        )
        #d.to_json(os.path.join(dir, "test_json.json"))

    def compare_prices(self):
        data_old = pd.read_csv()
        # TODO
        pass

def main():
    e = None
    max_attempts = 2
    for i in range(0, max_attempts):
        try:
            bot = FFraccion()
            bot.create_folders()
            bot.get_categorias()
            bot.browse_categorias()
            bot.get_med_data()
            bot.save_data()
            bot.shutdown()
            return bot.data_medicamentos
        except Exception as e:
            print(e)
            bot.shutdown()
    if e is not None:
        raise e


#%%
data = main()